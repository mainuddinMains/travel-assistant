
  # Map and Chatbot Interface

  This is a code bundle for Map and Chatbot Interface. The original project is available at https://www.figma.com/design/Ww3wql2O1Rca7kYUocHijU/Map-and-Chatbot-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  