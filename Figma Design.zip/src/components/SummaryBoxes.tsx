import { Car, Bus, Printer, Map } from 'lucide-react';
import { Card } from './ui/card';

export function SummaryBoxes() {
  const exportToGoogleMaps = () => {
    // In a real app, this would integrate with Google Maps API
    // For now, we'll show a placeholder action
    alert('Opening Google Maps with your dessert tour route...');
  };

  return (
    <div className="grid grid-cols-4 gap-3 mt-4">
      <Card className="p-4 text-center">
        <div className="flex flex-col items-center gap-2">
          <Car className="w-6 h-6 text-blue-600" />
          <div>
            <p className="text-sm text-muted-foreground">Car ETA</p>
            <p className="font-semibold">38 min</p>
            <p className="text-xs text-muted-foreground">10.1 km</p>
          </div>
        </div>
      </Card>
      
      <Card className="p-4 text-center">
        <div className="flex flex-col items-center gap-2">
          <Bus className="w-6 h-6 text-green-600" />
          <div>
            <p className="text-sm text-muted-foreground">Transit ETA</p>
            <p className="font-semibold">52 min</p>
            <p className="text-xs text-muted-foreground">Multiple routes</p>
          </div>
        </div>
      </Card>
      
      <Card className="p-4 text-center">
        <div className="flex flex-col items-center gap-2">
          <Printer className="w-6 h-6 text-purple-600" />
          <div>
            <p className="text-sm text-muted-foreground">Print</p>
            <p className="font-semibold">Itinerary</p>
            <p className="text-xs text-muted-foreground">Detailed route</p>
          </div>
        </div>
      </Card>
      
      <Card 
        className="p-4 text-center cursor-pointer hover:bg-gray-50 transition-colors"
        onClick={exportToGoogleMaps}
      >
        <div className="flex flex-col items-center gap-2">
          <Map className="w-6 h-6 text-red-600" />
          <div>
            <p className="text-sm text-muted-foreground">Export to</p>
            <p className="font-semibold">Google Maps</p>
            <p className="text-xs text-muted-foreground">Save to account</p>
          </div>
        </div>
      </Card>
    </div>
  );
}