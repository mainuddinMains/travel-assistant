import exampleImage from 'figma:asset/6ff0d4840d25cbdb33ca2a893c1c1913dbd3fb4d.png';

export function MapSection() {
  return (
    <div className="w-full h-full bg-gray-50 rounded-lg overflow-hidden">
      <img 
        src={exampleImage} 
        alt="Route optimization map showing Toronto locations"
        className="w-full h-full object-cover"
      />
    </div>
  );
}