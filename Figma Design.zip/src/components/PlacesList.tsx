import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { GripVertical, X, Car, Bus, MapPin, Star } from 'lucide-react';

interface Place {
  id: string;
  name: string;
  description: string;
  etaToCar?: string;
  etaToTransit?: string;
  distance?: string;
  googleRating?: number;
  googleReviews?: number;
}

export function PlacesList() {
  const [places, setPlaces] = useState<Place[]>([
    {
      id: '1',
      name: 'Ruru Baked',
      description: 'Artisanal bakery known for fresh bread and pastries. Popular breakfast spot with outdoor seating.',
      etaToCar: '12 min',
      etaToTransit: '18 min',
      distance: '3.2 km',
      googleRating: 4.6,
      googleReviews: 1247
    },
    {
      id: '2',
      name: 'Bang Bang Ice Cream & Bakery',
      description: 'Creative ice cream flavors and fresh baked goods. Local favorite for unique dessert combinations.',
      etaToCar: '8 min',
      etaToTransit: '15 min',
      distance: '2.1 km',
      googleRating: 4.4,
      googleReviews: 892
    },
    {
      id: '3',
      name: 'Sweet Olenka\'s Chocolate Shop',
      description: 'European-style chocolate shop with handcrafted truffles, macarons, and traditional desserts.',
      etaToCar: '15 min',
      etaToTransit: '22 min',
      distance: '4.2 km',
      googleRating: 4.8,
      googleReviews: 456
    },
    {
      id: '4',
      name: 'Bakerbots Baking',
      description: 'Modern bakery specializing in croissants, Danish pastries, and seasonal dessert offerings.',
      etaToCar: '10 min',
      etaToTransit: '16 min',
      distance: '2.8 km',
      googleRating: 4.5,
      googleReviews: 623
    },
    {
      id: '5',
      name: 'Dufflet Pastries',
      description: 'Iconic Toronto bakery famous for wedding cakes, cupcakes, and gourmet desserts since 1980.',
      etaToCar: '20 min',
      etaToTransit: '28 min',
      distance: '6.1 km',
      googleRating: 4.7,
      googleReviews: 2134
    },
    {
      id: '6',
      name: 'Soma Chocolatemaker',
      description: 'Bean-to-bar chocolate maker with artisanal chocolates, hot chocolate, and chocolate desserts.',
      etaToCar: '14 min',
      etaToTransit: '19 min',
      distance: '3.7 km',
      googleRating: 4.6,
      googleReviews: 789
    }
  ]);

  const removePlace = (id: string) => {
    setPlaces(places.filter(place => place.id !== id));
  };

  const movePlace = (id: string, direction: 'up' | 'down') => {
    const currentIndex = places.findIndex(place => place.id === id);
    if (
      (direction === 'up' && currentIndex === 0) ||
      (direction === 'down' && currentIndex === places.length - 1)
    ) {
      return;
    }

    const newPlaces = [...places];
    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    [newPlaces[currentIndex], newPlaces[targetIndex]] = [newPlaces[targetIndex], newPlaces[currentIndex]];
    setPlaces(newPlaces);
  };

  return (
    <div className="space-y-3">
        {places.map((place, index) => (
          <div key={place.id}>
            <Card className="p-4">
              <div className="flex items-start gap-3">
                <div className="flex flex-col gap-1 mt-1">
                  <button
                    onClick={() => movePlace(place.id, 'up')}
                    disabled={index === 0}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-50"
                  >
                    <GripVertical className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3>{place.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm">{place.googleRating}</span>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          ({place.googleReviews?.toLocaleString()} reviews)
                        </span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removePlace(place.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-3">
                    {place.description}
                  </p>
                  
                  {index < places.length - 1 && (
                    <div className="bg-gray-50 p-3 rounded-md">
                      <p className="text-xs text-muted-foreground mb-2">To next location:</p>
                      <div className="flex gap-4 text-sm">
                        <div className="flex items-center gap-1">
                          <Car className="w-3 h-3 text-blue-600" />
                          <span>{place.etaToCar}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Bus className="w-3 h-3 text-green-600" />
                          <span>{place.etaToTransit}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-gray-600" />
                          <span>{place.distance}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          </div>
        ))}
      </div>
  );
}