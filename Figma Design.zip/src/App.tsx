import { MapSection } from './components/MapSection';
import { SummaryBoxes } from './components/SummaryBoxes';
import { PlacesList } from './components/PlacesList';
import { Chatbot } from './components/Chatbot';

export default function App() {
  return (
    <div className="h-screen bg-gray-50 p-4">
      <div className="h-full grid grid-cols-2 gap-4">
        {/* Left Section */}
        <div className="flex flex-col">
          {/* Map - Better sized */}
          <div className="flex-1 mb-3 min-h-0">
            <MapSection />
          </div>
          
          {/* Summary Boxes */}
          <div className="h-28 flex-shrink-0">
            <SummaryBoxes />
          </div>
        </div>
        
        {/* Right Section */}
        <div className="flex flex-col gap-3 min-h-0">
          {/* Places List - Compact */}
          <div className="h-64 bg-white rounded-lg overflow-hidden flex-shrink-0">
            <div className="h-full flex flex-col">
              <div className="p-3 border-b flex-shrink-0">
                <h2>Suggestions For You</h2>
              </div>
              <div className="flex-1 p-3 overflow-y-auto min-h-0">
                <PlacesList />
              </div>
            </div>
          </div>
          
          {/* Chatbot - Takes remaining space */}
          <div className="flex-1 min-h-0">
            <Chatbot />
          </div>
        </div>
      </div>
    </div>
  );
}